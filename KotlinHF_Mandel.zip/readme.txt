KotlinHF Mandelbrot/Julia viewer app
install guide: 
- JDK 10 kell hozzá
- A könyvtárat kiszedve a zipből lehet idea-val importálni simán, csak Gradle kell mellé importálásnál 
- Indítani a Main.kt-ból kell


A gombok/irányítás ki van írva képernyőre, de console-on is olvasható.
A argumentumként lehet állítani a képernyő méretét, a dolgozó szálak számát, és a szálanként kiszámolandó terület méretét. Ha nem adunk külön, akkor írja a konzolban, hogy 960x576-os felbontáson és 16 szálon fut.
Indításkor egyszerűen utána kell írni sorba, pl: "MainKt 960 576 16 64" a 960x576-os felbontás, 16 szál, 64x64-es darabka módért.
 
A benchmark mód szándékosan fagyasztja meg a képernyőt (hogy ne nyomhassunk semmit közben), de console-on látható a haladás.

A benchmark utáni kész file-okat a két módból "chunkSizeBench.txt" és "threadCountBench.txt" néven menti le a program miután végzett. 
Tabulátorral tagoltak az értékek, oszlokok az egyes próbálkozások (16x számolja, hogy jobb átlagot adhasson), és sorban a különböző paraméterek találhatóak (régió méret, szál szám).

Első mód (U gombbal) fix 16 szálon megy. Futtatásával megnézi, hogy változtatva az egy szálnak adott számolandó terület méretét, hogy változik a render ideje.  (ez nekem 4 mag 8 szálon r5 1400-al kb 8 perc)
Második mód (P gombbal) fix (64,64) méretű területet számol úgy, hogy a futószalag szálait változtatja. (ez nekem 7 perc volt)