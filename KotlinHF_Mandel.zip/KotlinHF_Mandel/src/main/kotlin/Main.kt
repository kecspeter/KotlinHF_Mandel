import javafx.application.Application

fun main(args: Array<String>)
{
    Application.launch(AppWindow::class.java, *args)
}
